
from funcs import init_centroids

from load import run_image

def main():
    k = 2
    while (k < 17):
        centroids = init_centroids(1, k)
        print("k=%d:" %k)
        run_image(centroids)
        k = k+k

main()

