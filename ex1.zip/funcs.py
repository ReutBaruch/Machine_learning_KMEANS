import numpy as np
import scipy.spatial as sp
import matplotlib.pyplot as plt


def loss_function(copyArray, norm, centers):
    count = 0
    loss = 0
    sum = 0

    for line in range(len(copyArray)):
        for column in range(len(copyArray[line])):
            minDis = None
            distance = 0
            for center in range(len(centers)):
                distance = sp.distance.euclidean(norm[line][column], centers[center])
                if (minDis == None):
                    minDis = distance
                else:
                    if(distance < minDis):
                        minDis = distance

            #end of centers
            sum += minDis
            count += 1
        #end of columns
    #end of lines

    avg = sum/count
    vec = np.linalg.norm(avg)
    print(vec)
    return



def graph(iter, loss):
    #loss = [0.19,0.19,0.19,0.19,0.19,0.19,0.19,0.19,0.19,0.19]
    plt.plot(loss)
    plt.title('K = %d' %iter)
    plt.ylabel('Loss')
    plt.xlabel('Iterations')
    plt.show()
    return



def canculate_avg_for_centr(copyArray, norm, k, originalCenter):
    red = 0
    green = 0
    blue = 0
    counter = 0
    ret_val = [None] * 3
    for line in range(len(copyArray)):
        for column in range(len(copyArray[line])):
            if (copyArray[line][column] == k):
                red += norm[line][column][0]
                green += norm[line][column][1]
                blue += norm[line][column][2]
                counter += 1
        #end of columns
    #end of lines
    if (counter != 0):
        ret_val[0] = red/counter
        ret_val[1] = green/counter
        ret_val[2] = blue/counter
        return ret_val
    else:
        return originalCenter

def init_centroids(X, K):
    """
    Initializes K centroids that are to be used in K-Means on the dataset X.

    Parameters
    ----------
    X : ndarray, shape (n_samples, n_features)
        Samples, where n_samples is the number of samples and n_features is the number of features.
    K : int
        The number of centroids.

    Returns
    -------
    centroids : ndarray, shape (K, n_features)
    """
    if K == 2:
        return np.asarray([[0.        , 0.        , 0.        ],
                            [0.07843137, 0.06666667, 0.09411765]])
    elif K == 4:
        return np.asarray([[0.72156863, 0.64313725, 0.54901961],
                            [0.49019608, 0.41960784, 0.33333333],
                            [0.02745098, 0.        , 0.        ],
                            [0.17254902, 0.16862745, 0.18823529]])
    elif K == 8:
        return np.asarray([[0.01568627, 0.01176471, 0.03529412],
                            [0.14509804, 0.12156863, 0.12941176],
                            [0.4745098 , 0.40784314, 0.32941176],
                            [0.00784314, 0.00392157, 0.02745098],
                            [0.50588235, 0.43529412, 0.34117647],
                            [0.09411765, 0.09019608, 0.11372549],
                            [0.54509804, 0.45882353, 0.36470588],
                            [0.44705882, 0.37647059, 0.29019608]])
    elif K == 16:
        return np.asarray([[0.61568627, 0.56078431, 0.45882353],
                            [0.4745098 , 0.38039216, 0.33333333],
                            [0.65882353, 0.57647059, 0.49411765],
                            [0.08235294, 0.07843137, 0.10196078],
                            [0.06666667, 0.03529412, 0.02352941],
                            [0.08235294, 0.07843137, 0.09803922],
                            [0.0745098 , 0.07058824, 0.09411765],
                            [0.01960784, 0.01960784, 0.02745098],
                            [0.00784314, 0.00784314, 0.01568627],
                            [0.8627451 , 0.78039216, 0.69803922],
                            [0.60784314, 0.52156863, 0.42745098],
                            [0.01960784, 0.01176471, 0.02352941],
                            [0.78431373, 0.69803922, 0.60392157],
                            [0.30196078, 0.21568627, 0.1254902 ],
                            [0.30588235, 0.2627451 , 0.24705882],
                            [0.65490196, 0.61176471, 0.50196078]])
    else:
        print('This value of K is not supported.')
        return None