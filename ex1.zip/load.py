import numpy as np
import scipy.io as sio
import scipy.spatial as sp
import matplotlib.pyplot as plt
import math

from scipy.misc import imread
from funcs import init_centroids
from funcs import canculate_avg_for_centr
from funcs import loss_function
from funcs import graph

def run_image(B):
    # data preperation (loading, normalizing, reshaping)
    path = 'dog.jpeg'

    average = [None] *len(B)

    whichCenter = -1

    A = imread(path)
    A_norm = A.astype(float) / 255.
    copyA = [[0 for x in range(len(A_norm))] for y in range(len(A_norm))]
    temp = []

    for iteration in range(10):
        sum = 0
        count = 0
        for line in range(len(A_norm)):
            for column in range(len(A_norm)):
                myMinimum = -1
                for center in range(len(B)):
                    dist = sp.distance.euclidean(A_norm[line][column], B[center])
                    #dist = math.sqrt(sum([(a - b) ** 2 for a, b in zip(A_norm[line][column], B[center])]))

                    if (myMinimum == -1):
                        myMinimum = dist
                        whichCenter = center
                    else:
                        if(myMinimum >= dist):
                            myMinimum = dist
                            whichCenter = center
                #end of centers
                sum += myMinimum
                count += 1
                copyA[line][column] = whichCenter
            #end of columns
        #end of lines
        temp.append(sum/count)
        #print(sum/count)

        print("iter ", iteration, end = "")
        print(":", end = " ")
        for center in range(len(B)):
            #print("[",np.floor(B[center][0] *100)/100,",",np.floor(B[center][1]*100)/100, "]",end="")
            print(np.floor(B[center] * 100) / 100, end="")
            if (center != len(B) - 1):
                print(", ", end=" ")
            B[center] = canculate_avg_for_centr(copyA, A_norm, center, B[center])
        # end of recalculating the center
        print()
    # end of iterations

    print("iter 10:", end=" ")
    for center in range(len(B)):
        print("[",math.floor(B[center][0] * 100) / 100, "," , math.floor(B[center][1] * 100) / 100, ",", math.floor(B[center][2] * 100) / 100,"]", end="")
        if (center != len(B) - 1):
            print(", ", end=" ")


        for line in range(len(copyA)):
            for column in range(len(copyA[line])):
                if (copyA[line][column] == center):
                    A_norm[line][column] = B[center]


    #graph(16, temp)
    print()

    #for center in range(len(average)):
     #   print(np.floor(average[center] * 100) / 100, end="")

    img_size = A_norm.shape

    X = A_norm.reshape(img_size[0] * img_size[1], img_size[2])

    # plot the image
    plt.imshow(A_norm)
    plt.grid(False)
#    plt.show()




